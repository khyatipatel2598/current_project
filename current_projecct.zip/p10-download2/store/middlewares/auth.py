from django.shortcuts import redirect
def auth_middleware(get_response):


    def middleware(request):
        print(request.session.get('name'))
        if not request.session.get('name'):
            print('middleware')
            return redirect('login')

        response = get_response(request)
        return response

    return middleware
